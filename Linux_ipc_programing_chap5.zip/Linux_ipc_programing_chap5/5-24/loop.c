/************************************************
* Copyright(C) zhaixue.cc All rights reserved
*
*      Filename: loop.c
*        Author: litao.wang
*        E-mail: 3284757626@qq.com
*   Description: 
*        Create: 2019-07-23 13:15:31
* Last Modified: 2019-07-23 14:46:12
************************************************/
#include <stdio.h>

int main (void)
{
    while (1);
    return 0;
}
